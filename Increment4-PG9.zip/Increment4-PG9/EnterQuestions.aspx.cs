﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication7
{
    public partial class EnterQuestions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = "Entered  Successfully";
        }

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLSERV2014;AttachDbFilename=C:\Users\Manisha\Documents\Visual Studio 2010\Projects\WebApplication7\WebApplication7\App_Data\OCA.mdf;Integrated Security=True;User Instance=True");

        protected void Button1_Click(object sender, EventArgs e)
        {


            string insert = "insert into Questions(Slno,Question,option1,option2,option3,option4,correctans,qstyp,qstlevel,section) values(@slno,@question,@option1,@option2,@option3,@option4,@cans,@qstyp,@qstlevel,@section)";
            con.Open();
            SqlCommand cmd = new SqlCommand(insert, con);
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("@slno", 1 );
            cmd.Parameters.AddWithValue("@question", TextBox1.Text);
            cmd.Parameters.AddWithValue("@option1", TextBox2.Text);
            cmd.Parameters.AddWithValue("@option2", TextBox3.Text);
            cmd.Parameters.AddWithValue("@option3", TextBox4.Text);
            cmd.Parameters.AddWithValue("@option4", TextBox5.Text);
            cmd.Parameters.AddWithValue("@cans", TextBox6.Text);
            cmd.Parameters.AddWithValue("@qstyp", DropDownList1.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@qstlevel", DropDownList2.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@section", DropDownList3.SelectedItem.Text);
            //cmd.Parameters.AddWithValue("@Image", );


            cmd.ExecuteNonQuery();
            con.Close();
            Label1.Text = "Entered  Successfully";

        }
    }
}